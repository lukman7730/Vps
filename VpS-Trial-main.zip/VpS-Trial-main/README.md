# HOW TO CREATE
> Press the Fork button to create RDP (For Android / HP Users, Please Use Desktop Mode).

> visit https://dashboard.ngrok.com to get NGROK_AUTH_TOKEN

> Inside this Repo Go to Settings> Secrets> New repository secret

> Fill in the Name: Enter NGROK_AUTH_TOKEN

> Fill in Value: Visit https://dashboard.ngrok.com/auth/your-authtoken Copy and Paste in the value

> Press Add secret 

> Go to Action> CI> Run workflow

> Refresh Web and go to CI> build

> Press Down facing arrow button "RDP INFO LOGIN" To Get IP, User, Password.


>Toturial :https://youtu.be/wFDYTKDngDw


